//! AVM2 String representation

pub use crate::avm1::AvmString;
