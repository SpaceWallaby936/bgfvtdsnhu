//! `flash.events` namespace

pub mod event;
pub mod eventdispatcher;
pub mod ieventdispatcher;
