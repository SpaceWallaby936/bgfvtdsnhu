//! `flash.system` namespace

pub mod application_domain;
