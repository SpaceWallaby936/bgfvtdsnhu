//! `flash` namespace

pub mod display;
pub mod events;
pub mod system;
